package android.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class register extends AppCompatActivity{

    private SharedPreferences register_sp;
    //private Button btn3,btn4;
    //private EditText edit1,edit2,edit3;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_register);
        Button btn3 = (Button)findViewById(R.id.btnRegister);
        Button btn4 = (Button)findViewById(R.id.btnLinkToLoginScreen);

        btn3.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View v)
            {
                EditText edit1 = (EditText) findViewById(R.id.registername);
                EditText edit2 = (EditText) findViewById(R.id.registeremail);
                EditText edit3 = (EditText) findViewById(R.id.registerpassword);
                //String user = edit1.getText().toString();
                if(edit1.getText().toString().equals(""))
                {
                    Toast.makeText(register.this, "name can't be empty!",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    if(edit2.getText().toString().equals(""))
                    {
                        Toast.makeText(register.this, "email can't be empty!",Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        if(edit3.getText().toString().equals(""))
                        {
                            Toast.makeText(register.this, "Password can't be empty!",Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            register_sp=getSharedPreferences("dab", Context.MODE_PRIVATE);
                            Editor edit=register_sp.edit();
                            edit.putString("username", edit1.getText().toString());
                            edit.putString("email", edit2.getText().toString());
                            edit.putString("password", edit3.getText().toString());
                            edit.commit();
                            Toast.makeText(register.this, "Successfully Registered!",Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
        //setContentView(R.layout.layout_login);
        //setContentView(R.layout.activity_main);
        btn4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent i = new Intent(register.this , MainActivity.class);
                startActivity(i);
            }
        });
    }
}
