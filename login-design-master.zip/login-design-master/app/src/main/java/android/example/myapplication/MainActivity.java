package android.example.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class MainActivity extends AppCompatActivity {
    private SharedPreferences read_sp;
    //private String input_email;
    //private String input_pwd;
    private EditText email,pwd;
    private Button btn1,btn2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_login);

        //获取控件
        btn1 = (Button)findViewById(R.id.btnLinkToRegisterScreen);
        btn2 = (Button)findViewById(R.id.btnLogin);
        email = (EditText) findViewById(R.id.email);
        pwd = (EditText) findViewById(R.id.password);




        btn2.setOnClickListener(new View.OnClickListener()
        {


            @Override
            public void onClick(View v)
            {

                if(email.getText().toString().equals(""))
                {
                    Toast.makeText(MainActivity.this, "email can't be empty!",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    if(pwd.getText().toString().equals(""))
                    {
                        Toast.makeText(MainActivity.this, "Password can't be empty!",Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        read_sp=getSharedPreferences("dab", Context.MODE_PRIVATE);
                        String savedemail = read_sp.getString("email","");
                        String savedPassword = read_sp.getString("password","");

                        if(email.getText().toString().trim().equals(savedemail) && pwd.getText().toString().trim().equals(savedPassword))
                        {
                            Intent i = new Intent(MainActivity.this , welcome.class);
                            startActivity(i);
                        }
                        else
                        {
                            Toast.makeText(MainActivity.this, "Username or Password is wrong, please check or create an account!", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }
                }
            }

        });
        //setContentView(R.layout.layout_login);
        //setContentView(R.layout.activity_main);
        btn1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent i = new Intent(MainActivity.this , register.class);
                startActivity(i);
            }
        });
    }
}
